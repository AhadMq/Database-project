-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: productivefamilies
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `innestted`
--

DROP TABLE IF EXISTS `innestted`;
/*!50001 DROP VIEW IF EXISTS `innestted`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `innestted` AS SELECT 
 1 AS `product_id`,
 1 AS `pname`,
 1 AS `quantity`,
 1 AS `price`,
 1 AS `pdate`,
 1 AS `Edate`,
 1 AS `cart_id`,
 1 AS `s_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `somesel`
--

DROP TABLE IF EXISTS `somesel`;
/*!50001 DROP VIEW IF EXISTS `somesel`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `somesel` AS SELECT 
 1 AS `product_id`,
 1 AS `pname`,
 1 AS `quantity`,
 1 AS `price`,
 1 AS `pdate`,
 1 AS `Edate`,
 1 AS `cart_id`,
 1 AS `s_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `sss`
--

DROP TABLE IF EXISTS `sss`;
/*!50001 DROP VIEW IF EXISTS `sss`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `sss` AS SELECT 
 1 AS `o_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `btwn`
--

DROP TABLE IF EXISTS `btwn`;
/*!50001 DROP VIEW IF EXISTS `btwn`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `btwn` AS SELECT 
 1 AS `pname`,
 1 AS `price`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `joinorder`
--

DROP TABLE IF EXISTS `joinorder`;
/*!50001 DROP VIEW IF EXISTS `joinorder`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `joinorder` AS SELECT 
 1 AS `order_id`,
 1 AS `Fname`,
 1 AS `o_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `notin`
--

DROP TABLE IF EXISTS `notin`;
/*!50001 DROP VIEW IF EXISTS `notin`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `notin` AS SELECT 
 1 AS `customer_Id`,
 1 AS `Fname`,
 1 AS `Lname`,
 1 AS `address`,
 1 AS `phone`,
 1 AS `order_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `productanalysis`
--

DROP TABLE IF EXISTS `productanalysis`;
/*!50001 DROP VIEW IF EXISTS `productanalysis`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `productanalysis` AS SELECT 
 1 AS `minprice`,
 1 AS `maxprice`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customerinfo`
--

DROP TABLE IF EXISTS `customerinfo`;
/*!50001 DROP VIEW IF EXISTS `customerinfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `customerinfo` AS SELECT 
 1 AS `count(customer_Id)`,
 1 AS `address`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `leftjoin`
--

DROP TABLE IF EXISTS `leftjoin`;
/*!50001 DROP VIEW IF EXISTS `leftjoin`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `leftjoin` AS SELECT 
 1 AS `Fname`,
 1 AS `order_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `productcart`
--

DROP TABLE IF EXISTS `productcart`;
/*!50001 DROP VIEW IF EXISTS `productcart`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `productcart` AS SELECT 
 1 AS `quantity`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rightjoin`
--

DROP TABLE IF EXISTS `rightjoin`;
/*!50001 DROP VIEW IF EXISTS `rightjoin`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `rightjoin` AS SELECT 
 1 AS `Fname`,
 1 AS `customer_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `dist`
--

DROP TABLE IF EXISTS `dist`;
/*!50001 DROP VIEW IF EXISTS `dist`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `dist` AS SELECT 
 1 AS `count(distinct Sname)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!50001 DROP VIEW IF EXISTS `drivers`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `drivers` AS SELECT 
 1 AS `Dname`,
 1 AS `work_hours`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `storeproduct`
--

DROP TABLE IF EXISTS `storeproduct`;
/*!50001 DROP VIEW IF EXISTS `storeproduct`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `storeproduct` AS SELECT 
 1 AS `product_id`,
 1 AS `pname`,
 1 AS `quantity`,
 1 AS `price`,
 1 AS `pdate`,
 1 AS `Edate`,
 1 AS `cart_id`,
 1 AS `s_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `limitedhours`
--

DROP TABLE IF EXISTS `limitedhours`;
/*!50001 DROP VIEW IF EXISTS `limitedhours`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `limitedhours` AS SELECT 
 1 AS `Driver_id`,
 1 AS `Dname`,
 1 AS `phone`,
 1 AS `work_hours`,
 1 AS `customer_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `isnull`
--

DROP TABLE IF EXISTS `isnull`;
/*!50001 DROP VIEW IF EXISTS `isnull`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `isnull` AS SELECT 
 1 AS `Dname`,
 1 AS `work_hours`,
 1 AS `phone`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `selcall`
--

DROP TABLE IF EXISTS `selcall`;
/*!50001 DROP VIEW IF EXISTS `selcall`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `selcall` AS SELECT 
 1 AS `product_id`,
 1 AS `pname`,
 1 AS `quantity`,
 1 AS `price`,
 1 AS `pdate`,
 1 AS `Edate`,
 1 AS `cart_id`,
 1 AS `s_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `unionquery`
--

DROP TABLE IF EXISTS `unionquery`;
/*!50001 DROP VIEW IF EXISTS `unionquery`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `unionquery` AS SELECT 
 1 AS `type`,
 1 AS `Fname`,
 1 AS `address`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `productprice`
--

DROP TABLE IF EXISTS `productprice`;
/*!50001 DROP VIEW IF EXISTS `productprice`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `productprice` AS SELECT 
 1 AS `pname`,
 1 AS `price`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `innestted`
--

/*!50001 DROP VIEW IF EXISTS `innestted`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `innestted` AS select `product`.`product_id` AS `product_id`,`product`.`pname` AS `pname`,`product`.`quantity` AS `quantity`,`product`.`price` AS `price`,`product`.`pdate` AS `pdate`,`product`.`Edate` AS `Edate`,`product`.`cart_id` AS `cart_id`,`product`.`s_id` AS `s_id` from `product` where `product`.`quantity` in (select `cart`.`quantity` from `cart`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `somesel`
--

/*!50001 DROP VIEW IF EXISTS `somesel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `somesel` AS select `product`.`product_id` AS `product_id`,`product`.`pname` AS `pname`,`product`.`quantity` AS `quantity`,`product`.`price` AS `price`,`product`.`pdate` AS `pdate`,`product`.`Edate` AS `Edate`,`product`.`cart_id` AS `cart_id`,`product`.`s_id` AS `s_id` from `product` where `product`.`price` > any (select `product`.`price` from `product` where (`product`.`price` > 20)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sss`
--

/*!50001 DROP VIEW IF EXISTS `sss`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sss` AS select `orders`.`o_date` AS `o_date` from `orders` where (`orders`.`o_date` = '2023-04-01' in (select `product`.`pdate` from `product` where (`product`.`pdate` = '2023-04-01'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `btwn`
--

/*!50001 DROP VIEW IF EXISTS `btwn`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `btwn` AS select `product`.`pname` AS `pname`,`product`.`price` AS `price` from `product` where (`product`.`price` between 20 and 35) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `joinorder`
--

/*!50001 DROP VIEW IF EXISTS `joinorder`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `joinorder` AS select `orders`.`order_id` AS `order_id`,`customer`.`Fname` AS `Fname`,`orders`.`o_date` AS `o_date` from (`orders` join `customer` on((`orders`.`product_id` = `customer`.`customer_Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `notin`
--

/*!50001 DROP VIEW IF EXISTS `notin`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `notin` AS select `customer`.`customer_Id` AS `customer_Id`,`customer`.`Fname` AS `Fname`,`customer`.`Lname` AS `Lname`,`customer`.`address` AS `address`,`customer`.`phone` AS `phone`,`customer`.`order_id` AS `order_id` from `customer` where (`customer`.`address` not in ('Dammam','qatif')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `productanalysis`
--

/*!50001 DROP VIEW IF EXISTS `productanalysis`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `productanalysis` AS select min(`product`.`price`) AS `minprice`,max(`product`.`price`) AS `maxprice` from `product` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customerinfo`
--

/*!50001 DROP VIEW IF EXISTS `customerinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customerinfo` AS select count(`customer`.`customer_Id`) AS `count(customer_Id)`,`customer`.`address` AS `address` from `customer` where (`customer`.`address` <> 'jubail') group by `customer`.`address` having (count(`customer`.`customer_Id`) >= 3) order by count(`customer`.`customer_Id`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `leftjoin`
--

/*!50001 DROP VIEW IF EXISTS `leftjoin`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `leftjoin` AS select `customer`.`Fname` AS `Fname`,`orders`.`order_id` AS `order_id` from (`customer` left join `orders` on((`customer`.`customer_Id` = `orders`.`product_id`))) order by `customer`.`Fname` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `productcart`
--

/*!50001 DROP VIEW IF EXISTS `productcart`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `productcart` AS select `product`.`quantity` AS `quantity` from `product` where `product`.`quantity` in (select `cart`.`Cart_id` from `cart` where (`cart`.`quantity` = 5)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rightjoin`
--

/*!50001 DROP VIEW IF EXISTS `rightjoin`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rightjoin` AS select `c`.`Fname` AS `Fname`,`d`.`customer_id` AS `customer_id` from (`driver` `d` left join `customer` `c` on((`c`.`customer_Id` = `d`.`customer_id`))) order by `d`.`Dname` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dist`
--

/*!50001 DROP VIEW IF EXISTS `dist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dist` AS select count(distinct `stores`.`Sname`) AS `count(distinct Sname)` from `stores` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `drivers`
--

/*!50001 DROP VIEW IF EXISTS `drivers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `drivers` AS select `driver`.`Dname` AS `Dname`,`driver`.`work_hours` AS `work_hours` from `driver` where ((`driver`.`work_hours` < 10) and (`driver`.`Dname` like 'A%')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `storeproduct`
--

/*!50001 DROP VIEW IF EXISTS `storeproduct`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `storeproduct` AS select `product`.`product_id` AS `product_id`,`product`.`pname` AS `pname`,`product`.`quantity` AS `quantity`,`product`.`price` AS `price`,`product`.`pdate` AS `pdate`,`product`.`Edate` AS `Edate`,`product`.`cart_id` AS `cart_id`,`product`.`s_id` AS `s_id` from `product` where (`product`.`s_id` = 704) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `limitedhours`
--

/*!50001 DROP VIEW IF EXISTS `limitedhours`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `limitedhours` AS select `driver`.`Driver_id` AS `Driver_id`,`driver`.`Dname` AS `Dname`,`driver`.`phone` AS `phone`,`driver`.`work_hours` AS `work_hours`,`driver`.`customer_id` AS `customer_id` from `driver` order by `driver`.`work_hours` limit 1,5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `isnull`
--

/*!50001 DROP VIEW IF EXISTS `isnull`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `isnull` AS select `driver`.`Dname` AS `Dname`,`driver`.`work_hours` AS `work_hours`,`driver`.`phone` AS `phone` from `driver` where (`driver`.`phone` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `selcall`
--

/*!50001 DROP VIEW IF EXISTS `selcall`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `selcall` AS select `product`.`product_id` AS `product_id`,`product`.`pname` AS `pname`,`product`.`quantity` AS `quantity`,`product`.`price` AS `price`,`product`.`pdate` AS `pdate`,`product`.`Edate` AS `Edate`,`product`.`cart_id` AS `cart_id`,`product`.`s_id` AS `s_id` from `product` where `product`.`product_id` = all (select `cart`.`product_id` from `cart`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `unionquery`
--

/*!50001 DROP VIEW IF EXISTS `unionquery`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `unionquery` AS select 'customer' AS `type`,`customer`.`Fname` AS `Fname`,`customer`.`address` AS `address` from `customer` union select 'store' AS `type`,`stores`.`Sname` AS `Sname`,`stores`.`city` AS `city` from `stores` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `productprice`
--

/*!50001 DROP VIEW IF EXISTS `productprice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `productprice` AS select `product`.`pname` AS `pname`,`product`.`price` AS `price` from `product` where (`product`.`price` > 20) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-11 16:02:10
